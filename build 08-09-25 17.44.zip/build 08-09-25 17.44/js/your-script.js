window.addEventListener('load', function() {
	var loader = document.getElementById('loaderone');
	loader.classList.add('hide');
  });
  